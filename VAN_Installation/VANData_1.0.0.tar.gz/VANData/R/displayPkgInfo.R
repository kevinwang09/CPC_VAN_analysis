##################################################################
##	Display package info
##
##	Input:None
##	Output: console display
##################################################################

displayPackageInfo = function() { print(ls()) }
